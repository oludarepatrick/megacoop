function copy_to_clipboard() {
    var copyText = document.getElementById("url");
    copyText.select();
    document.execCommand("copy");
    alert("Copied the text: " + copyText.value);
}

function file_upload_fix(id, file_label) {
    var file_path = document.getElementById(id).value;
    document.getElementById(file_label).innerHTML = file_path.split("\\")[2];
}

function show_recipient() {
    recip_type = $('#recip_type').val();
    if (recip_type !== 'custom') {
        $("#recipients-box").fadeOut('slow');
        return;
    }

    if (recip_type === 'custom') {
        $("#recipients-box").fadeIn('slow');
        return;
    }
}

function show_statement_type() {
    statement_type = $('#statement_type').val();
    if (statement_type === 'loan') {
        $("#savings_type_box").hide();
        $("#loan_type_box").show();
        return;
    }

    if (statement_type === 'savings') {
        $("#loan_type_box").hide();
        $("#savings_type_box").show();
        return;
    }
}
function change_user_group() {
    user_group = $('#user_group').val();
    if (user_group == '1') {
        $("#role_id_box").fadeIn();
        return;
    }
    if (user_group == '2') {
        $("#role_id_box").fadeOut();
        return;
    }
}

$(document).ready(function () {
    var max_fields = 200; //maximum input boxes allowed
    var wrapper = $(".input_fields_wrap"); //Fields wrapper
    var add_button = $(".add_field_button"); //Add button ID

    var x = 1; //initlal text box count
    $(add_button).click(function (e) { //on add input button click
        e.preventDefault();
        if (x < max_fields) { //max input box allowed
            x++; //text box increment
            $(wrapper).append('<div class="row mt-2">\n\
<div class="form-group col-md-3"><input placeholder="Next of Kin Full Name" class="form-control" type="text" name="kin_name[]"/></div> \n\
<div class="form-group col-md-3"><input placeholder="Next of Kin Phone" class="fee_val form-control" type="text" name="kin_phone[]"/></div>\n\
<div class="form-group col-md-5"><input placeholder="Next of Kin Address" class="fee_val form-control" type="text" name="kin_address[]"/></div>\n\
<div class="form-group col-md-1"><button class="btn btn-sm btn-danger remove_field">x</button></div>\n\
</div>'); //add input box
        }
    });

    $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text
        e.preventDefault();

        var d = $(this).parent('div');
        d.parent('div').remove();
        x--;
    });
    $('.close').click(function () {
        $("#err_box").hide();
    });
});

const  wait_loader = (hide, show) => {
    document.getElementById(hide).style.display = 'none';
    document.getElementById(show).style.display = 'inline';
};

function generate_savings_record() {
    $('#hide_generate_savin_btn').hide();
    $('#wait_generate_savin_btn').show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/get_savings_type',
//        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'error') {
                    $('#saving_notice_triger').click();
                    $('#hide_generate_savin_btn').show();
                    $('#wait_generate_savin_btn').hide();

                } else {
                    $.ajax({
                        type: "get",
                        url: base_url + 'migration/generate_savings_template',
                        dataType: "json",
                        success: function (data) {
                            if (data !== null) {
                                if (data.status === 'success') {
                                    $("#savings_template_download_btn").attr('href', base_url + data.message);
                                    $('#savings_template_download').show();
                                    $('#wait_generate_savin_btn').hide();
                                    $('#hide_generate_savin_btn').show();
                                } else {
                                    $('#wait_generate_savin_btn').hide();
                                    $('#hide_generate_savin_btn').show();
                                }
                            }
                        }
                    });

                }
            }
        }
    });
}

function generate_loan_record() {
    $('#hide_generate_loan_btn').hide();
    $('#wait_generate_loan_btn').show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/get_loan_type',
//        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'error') {
                    $('#loan_notice_triger').click();
                    $('#hide_generate_loan_btn').show();
                    $('#wait_generate_loan_btn').hide();

                } else {
                    $.ajax({
                        type: "get",
                        url: base_url + 'migration/generate_loan_template',
                        dataType: "json",
                        success: function (data) {
                            if (data !== null) {
                                if (data.status === 'success') {
                                    $("#loan_template_download_btn").attr('href', base_url + data.message);
                                    $('#loan_template_download').show();
                                    $('#wait_generate_loan_btn').hide();
                                    $('#hide_generate_loan_btn').show();
                                } else {
                                    $('#wait_generate_loan_btn').hide();
                                    $('#hide_generate_loan_btn').show();
                                }
                            }
                        }
                    });

                }
            }
        }
    });
}

function generate_credit_sales_record() {
    $('#hide_generate_credit_sales_btn').hide();
    $('#wait_generate_credit_sales_btn').show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/get_product_type',
//        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'error') {
                    $('#credit_sales_notice_triger').click();
                    $('#hide_generate_credit_sales_btn').show();
                    $('#wait_generate_credit_sales_btn').hide();

                } else {
                    $.ajax({
                        type: "get",
                        url: base_url + 'migration/generate_credit_sales_template',
                        dataType: "json",
                        success: function (data) {
                            if (data !== null) {
                                if (data.status === 'success') {
                                    $("#credit_sales_template_download_btn").attr('href', base_url + data.message);
                                    $('#credit_sales_template_download').show();
                                    $('#wait_generate_credit_sales_btn').hide();
                                    $('#hide_generate_credit_sales_btn').show();
                                } else {
                                    $('#wait_generate_credit_sales_btn').hide();
                                    $('#hide_generate_credit_sales_btn').show();
                                }
                            }
                        }
                    });

                }
            }
        }
    });
}

function generate_savings_template() {
    $('#hide_generate_savin_btn').hide();
    $('#wait_generate_savin_btn').show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/get_savings_type',
//        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'error') {
                    $('#saving_notice_triger').click();
                    $('#hide_generate_savin_btn').show();
                    $('#wait_generate_savin_btn').hide();

                } else {
                    $.ajax({
                        type: "get",
                        url: base_url + 'savings/generate_savings_template',
                        dataType: "json",
                        success: function (data) {
                            if (data !== null) {
                                if (data.status === 'success') {
                                    $("#savings_template_download_btn").attr('href', base_url + data.message);
                                    $('#savings_template_download').show();
                                    $('#wait_generate_savin_btn').hide();
                                    $('#hide_generate_savin_btn').show();
                                } else {
                                    $('#wait_generate_savin_btn').hide();
                                    $('#hide_generate_savin_btn').show();
                                }
                            }
                        }
                    });

                }
            }
        }
    });
}

function generate_credit_sales_repayment_template() {
    loan_type = $("#loan_type_1").val();
    if (loan_type == "") {
        $("#error_text").text('Please Select Product Type');
        return $("#error_notify").modal('show');
    }

    $('#hide_generate_savin_btn').hide();
    $('#wait_generate_savin_btn').show();
    $.ajax({
        type: "get",
        data: {loan_type: loan_type},
        url: base_url + 'creditsalesrepayment/generate_creditsales_template',
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#savings_template_download_btn").attr('href', base_url + data.message);
                    $('#savings_template_download').show();
                    $('#wait_generate_savin_btn').hide();
                    $('#hide_generate_savin_btn').show();
                } else {
                    $('#wait_generate_savin_btn').hide();
                    $('#hide_generate_savin_btn').show();
                }
            }
        }
    });
}

function change_theme(color) {
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/change_theme',
        data: {color: color},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    location.reload();
                }
            }
        }
    });
}

function change_side_bar(status) {
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/change_side_bar',
        data: {status: status},
        dataType: "json",
        success: function (data) {
            if (data !== null) {

            }
        }
    });
}

function member_approval(status, user_id) {
    $.ajax({
        type: "get",
        url: base_url + 'registration/ajax_member_approval',
        data: {status: status, user_id: user_id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
//                if (data.status === 'success') {
//                    location.reload();
//                } 
            }
        }
    });
}

function edit_role(id) {
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'users/ajax_get_role',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#id").val(data.message.id);
                    $("#name").val(data.message.name);
                    $("#description").val(data.message.description);
                }
            }
        }
    });
}

function edit_loan_type(id) {
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'categories/ajax_get_loan_type',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#id").val(data.message.id);
                    $("#name").val(data.message.name);
                    $("#rate").val(data.message.rate);
                    $("#guarantor").val(data.message.guarantor);
                    $("#min_month").val(data.message.min_month);
                    $("#max_month").val(data.message.max_month);
                    $("#description").val(data.message.description);
                }
            }
        }
    });
}

function edit_savings_type(id) {
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'categories/ajax_get_savings_type',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#id").val(data.message.id);
                    $("#name").val(data.message.name);
                    $("#description").val(data.message.description);
                }
            }
        }
    });
}

function edit_investment(id) {
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'investment/ajax_get_investment',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#id").val(data.message.id);
                    $("#investment_type").val(data.message.investment_type);
                    $("#amount").val(data.message.amount);
                    $("#roi").val(data.message.roi);
                    $("#rate").val(data.message.rate);
                    $("#maturity_year").val(data.message.maturity_year);
                    $("#start_date").val(data.message.start_date);
                    $("#end_date").val(data.message.end_date);
                    $("#description").val(data.message.description);
                }
            }
        }
    });
}

function edit_investment_type(id) {
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'categories/ajax_get_investment_type',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#id").val(data.message.id);
                    $("#name").val(data.message.name);
                    $("#description").val(data.message.description);
                }
            }
        }
    });
}

function edit_product_type(id) {
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'categories/ajax_get_product_type',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#id").val(data.message.id);
                    $("#name").val(data.message.name);
                    $("#rate").val(data.message.rate);
                    $("#guarantor").val(data.message.guarantor);
                    $("#min_month").val(data.message.min_month);
                    $("#max_month").val(data.message.max_month);
                    $("#description").val(data.message.description);
                }
            }
        }
    });
}

function get_savings_info() {
    member_id = $("#member_id").val();
    savings_type = $("#savings_type").val();
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_get_savings_info',
        data: {member_id: member_id, savings_type: savings_type},
        dataType: "json",
        success: function (data) {

            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#saving-history").fadeIn(1500);
                    $("#full_name").text(data.message.full_name);
                    $("#wallet_bal").text(data.message.wallet_bal);
                    $("#month_1").text(data.message.month);
                    $("#year_1").text(data.message.year);
                    $("#amount_1").text(data.message.amount);
                    $("#savings_type").text(data.message.savings_types);
                } else {
                    $("#saving-history").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').modal('show');
                }
            }
        }
    });
}

function get_loan_info() {
    member_id = $("#member_id").val();
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_get_loan_info',
        data: {member_id: member_id},
        dataType: "json",
        success: function (data) {

            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#exixting-loans").fadeIn(1500);
                    $("#full_name").text(data.message.full_name);
                    $("#bal").text(data.message.bal);
                    $("#total").text(data.message.total);
                    $("#paid").text(data.message.paid);
                    $("#balance").text(data.message.balance);
                } else {
                    $("#exixting-loans").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').click();
                }
            }
        }
    });
}

function get_credit_sales_info() {
    member_id = $("#member_id").val();
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_get_credit_sales_info',
        data: {member_id: member_id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#exixting-loans").fadeIn(1500);
                    $("#full_name").text(data.message.full_name);
                    $("#bal").text(data.message.bal);
                    $("#total").text(data.message.total);
                    $("#paid").text(data.message.paid);
                    $("#balance").text(data.message.balance);
                } else {
                    $("#exixting-loans").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').click();
                }
            }
        }
    });
}

function get_withdrawal_info() {
    member_id = $("#member_id").val();
    savings_type = $("#savings_type").val();
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_get_withdrawal_info',
        data: {member_id: member_id, savings_type: savings_type},
        dataType: "json",
        success: function (data) {

            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#exixting-loans").fadeIn(1500);
                    $("#full_name").text(data.message.full_name);
                    $("#bal").text(data.message.bal);
                    $("#total").text(data.message.total);
                    $("#paid").text(data.message.paid);
                    $("#balance").text(data.message.balance);
                } else {
                    $("#exixting-loans").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').modal('show');
                    $("#spinner").hide();
                }
            }
        }
    });
}

function preview_loan_schedule() {
    amount = $("#amount").val();
    tenure = parseInt($("#tenure").val());
    loan_type = $("#loan_type").val();

    if (amount == '') {
        return alert('Amount field is required');
    }
    ;
    if (isNaN(tenure) == true || tenure < 1) {
        return alert('Tenure field is required');
    }
    ;

    if (loan_type == '') {
        return alert('Loan type field is required');
    }
    ;

    $("#preview_loan_schedule_hide").hide();
    $("#preview_loan_schedule_show").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_preview_loan_schedule',
        data: {amount: amount, tenure: tenure, loan_type: loan_type},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#preview_loan_schedule_hide").show();
                    $("#preview_loan_schedule_show").hide();
                    $("#principal").text(data.message.principal);
                    $("#interest").text(data.message.interest);
                    $("#total_due").text(data.message.total_due);
                    $("#monthly_due").text(data.message.monthly_due);
                    $("#tenure1").text(data.message.tenure + " month(s)");
                    $("#display_schedule").click();
                }
            }
        }
    });
}

function preview_credit_ssales_schedule() {
    amount = $("#amount").val();
    tenure = parseInt($("#tenure").val());
    product_type = $("#product_type").val();

    if (amount == '') {
        return alert('Amount field is required');
    }
    ;
    if (isNaN(tenure) == true || tenure < 1) {
        return alert('Tenure field is required');
    }
    ;

    if (product_type == '') {
        return alert('Product type field is required');
    }
    ;

    $("#preview_loan_schedule_hide").hide();
    $("#preview_loan_schedule_show").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_preview_credit_sales_schedule',
        data: {amount: amount, tenure: tenure, product_type: product_type},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#preview_loan_schedule_hide").show();
                    $("#preview_loan_schedule_show").hide();
                    $("#principal").text(data.message.principal);
                    $("#interest").text(data.message.interest);
                    $("#total_due").text(data.message.total_due);
                    $("#monthly_due").text(data.message.monthly_due);
                    $("#tenure1").text(data.message.tenure + " month(s)");
                    $("#display_schedule").click();
                }
            }
        }
    });
}

function generate_loan_guarantor_field() {
    loan_type = $("#loan_type").val();
    $("#spinner1").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_generate_loan_guarantor_field',
        data: {loan_type: loan_type},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner1").hide();
                    $("#guarantors-wraper").fadeIn(1500);
                    $("#tenure").val(data.message.tenure);
                    fields = '';
                    fields_header_one = '<div class="col-12 guarantor-header-one"><label class=" text-danger"> ' + data.message.guarantors + ' Guarantor required, Please fill appropriately</label></div>';
                    fields_header_two = '<div class="col-12 guarantor-header-two"><label class=" text-danger">Guarantor NOT required</label></div>';
                    for (i = 1; i <= parseInt(data.message.guarantors); i++) {
                        fields += '<div class="form-group guarantor-fields col-md-6 mt-2">\n\
<div class="input-group">\n\
<div class="input-group-prepend">\n\
<span class="input-group-text bg-primary text-white" id="basic-addon1">' + i + '</span>\n\
</div>\n\
<input type="text" class="form-control" required placeholder="Enter Gurantor Member ID" name=guarantor[] aria-describedby="basic-addon1">\n\
</div>\n\
</div>';
                    }
                    if (fields !== '') {
                        $("div").remove('.guarantor-header-two');
                        $("div").remove('.guarantor-header-one');
                        $("div").remove('.guarantor-fields');
                        $("#guarantors-wraper").append(fields_header_one);
                        $("#guarantors-wraper").append(fields);
                    } else {
                        $("#guarantors-wraper").append(fields_header_two);
                        $("div").remove('.guarantor-header-one');
                        $("div").remove('.guarantor-fields');
                    }
                } else {
                    $("guarantors-wraper").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').click();
                }
            }
        }
    });
}

function generate_credit_sales_guarantor_field() {
    product_type = $("#product_type").val();
    $("#spinner1").show();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_generate_credit_sales_guarantor_field',
        data: {product_type: product_type},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner1").hide();
                    $("#guarantors-wraper").fadeIn(1500);
                    $("#tenure").val(data.message.tenure);
                    fields = '';
                    fields_header_one = '<div class="col-12 guarantor-header-one"><label class=" text-danger"> ' + data.message.guarantors + ' Guarantor required, Please fill appropriately</label></div>';
                    fields_header_two = '<div class="col-12 guarantor-header-two"><label class=" text-danger">Guarantor NOT required</label></div>';
                    for (i = 1; i <= parseInt(data.message.guarantors); i++) {
                        fields += '<div class="form-group guarantor-fields col-md-6 mt-2">\n\
<div class="input-group">\n\
<div class="input-group-prepend">\n\
<span class="input-group-text bg-primary text-white" id="basic-addon1">' + i + '</span>\n\
</div>\n\
<input type="text" class="form-control" required placeholder="Enter Gurantor Member ID" name=guarantor[] aria-describedby="basic-addon1">\n\
</div>\n\
</div>';
                    }
                    if (fields !== '') {
                        $("div").remove('.guarantor-header-two');
                        $("div").remove('.guarantor-header-one');
                        $("div").remove('.guarantor-fields');
                        $("#guarantors-wraper").append(fields_header_one);
                        $("#guarantors-wraper").append(fields);
                    } else {
                        $("#guarantors-wraper").append(fields_header_two);
                        $("div").remove('.guarantor-header-one');
                        $("div").remove('.guarantor-fields');
                    }
                } else {
                    $("guarantors-wraper").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').click();
                }
            }
        }
    });
}

function disburse_option(id) {
    $.ajax({
        type: "get",
        url: base_url + 'loan/ajax_disburse_option',
        data: {id: id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    $("#manual_disbursement").attr("href", data.message.url);
                    $("#disburse_option").modal('show');
                } else {
                    $('#error_notify').click();
                }
            }
        }
    });
}

function get_payment_break_down() {
    amount = $("#amount").val();
    gate_way = $("#gate_way").val();
    if (amount == "" || amount <= 0) {
        $("#error_text").text('Invalid amount');
        return $("#error_notify").modal('show');
    }
    $("#spinner").show();
    $.ajax({
        type: "get",
        url: base_url + 'member/wallet/ajax_get_payment_break_down',
        data: {amount: amount, gate_way: gate_way},
        dataType: "json",
        success: function (data) {

            if (data !== null) {
                if (data.status === 'success') {
                    $("#spinner").hide();
                    $("#payment_breakdown").fadeIn('slow');
                    $("#fee").text(data.message.fee);
                    $("#total").text(data.message.total);
                    $("#amount-one").text(data.message.amount);
                } else {
                    $("#spinner").hide();
                    $("#payment_breakdown").hide();
                    $("#error_text").text(data.message);
                    $('#error_notify').click();
                }
            }
        }
    });
}

function change_country() {
    country_id = $("#country").val();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_get_states_and_banks',
        data: {country_id: country_id},
        dataType: "json",
        success: function (data) {

            if (data !== null) {
                if (data.status === 'success') {
                    var x;
                    for (x in data.body) {
                        $("#state").append("<option value=" + data.body[x].id + ">" + data.body[x].name + "</option>");
                    }
                    var y;
                    for (y in data.banks) {
                        $("#bank_id").append("<option value=" + data.banks[y].id + ">" + data.banks[y].bank_name + "</option>");
                    }

                }
            }
        }
    });
}

function change_state() {
    state_id = $("#state").val();
    $.ajax({
        type: "get",
        url: base_url + 'commonapi/ajax_get_city',
        data: {state_id: state_id},
        dataType: "json",
        success: function (data) {
            if (data !== null) {
                if (data.status === 'success') {
                    var x;
                    for (x in data.body) {
                        $("#city").append("<option value=" + data.body[x].id + ">" + data.body[x].name + "</option>");
                    }

                }
            }
        }
    });
}
